##
-- model.py: Defines the neural network model.

-- placedb.py: Handles data preprocessing and placement database construction.

**2. Sampling**
-- sample.py: Performs sampling. The generated visualization results are saved in ./result, and the newly generated placement coordinate file is saved under the corresponding input benchmark directory with the suffix *_new.pl.

Example command:
python sample.py --input_file ./json_file/ibm01 --file ./HB/ibm01



##### HB+，GSRC，MCNC are from："Solving hard instances of floorplacement"， http://vlsicad.eecs.umich.edu/BK/GSRCbench/.edu/BK/FPUtils/ and http://vlsicad.eecs.umich.edu/BK/MCNCbench/， respectively.


##### This repository contains the code used for initial floorplan generation. Please note that the code associated with ICCAD'23 is unavailable due to copyright restrictions.
