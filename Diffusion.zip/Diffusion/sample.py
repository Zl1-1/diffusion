from model import Net,DenoiseDiffusion
import torch
import numpy as np
import torch.nn as nn
import os
from tqdm import tqdm 

import dgl

import time
from placedb import placedb,dgl_graph,plot
# import itertools
import random
import logging
from rtree import index  
import json
import argparse



torch.cuda.empty_cache() 
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:128'
# os.environ['CUDA_VISIBLE_DEVICES'] = '2,3,4'   
device = torch.device('cuda:0' if torch.cuda.is_available() else "cpu")




def set_seed(seed):
    random.seed(seed)  # Python random模块
    np.random.seed(seed)  # Numpy随机性
    torch.manual_seed(seed)  # PyTorch CPU随机性
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)  # PyTorch GPU随机性
        torch.cuda.manual_seed_all(seed)  # 多个GPU的随机性
    
    # 以下确保某些确定性操作
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

set_seed(42)  # 替换成你希望使用的种子值


def predict(xt,g,net_info,block,pos):
    net=Net(2,32,4,32)
            # net=DenoiseDiffusion(2,32,4,32,1000,device)
    net.load_state_dict(torch.load('./weight/train_weight_res_mlp.pt', map_location=device))
    # net=nn.DataParallel(net,device_ids=[2,3])
    net.to(device)
    xt = xt.to(device)
    g = g.to(device)
    dm=DenoiseDiffusion(net,1000,device)
  
  

    with torch.cuda.amp.autocast(enabled=False):
        start_time=time.time()
        for t in tqdm(reversed(range(100))):

                xt_1= dm.p_sample(xt, g,torch.tensor([t]).to(device),edge_idex_stack,b2b_src_idex_stack,b2b_dst_idex_stack,h_param,d_param,net_info,block,pos)
                # print(xt_1)
                xt = xt_1.detach().clone()  # 创建 xt_1 的副本并断开计算图


                xt[:, :,:2]=xt[:,:, :2].clamp(-1, 1)

        mid_xt=xt.clone().squeeze()
        raw_xt=mid_xt[:,:2]* size[2:4]+ size[2:4]
        print(time.time()-start_time)

        fea[:,2:4]=raw_xt
                   
        plot(fea,h_param,d_param)
    return xt
def pre_hpwl(g):
    edge_idex=[]
    src_b_list=[]
    dst_b_list=[]
    idx=0
    _, dst = g.edges(etype=('pin', 'p2b', 'block_2'))
    src_b,dst_b=g.edges(etype=('block_1', 'b2b', 'block_1'))
    for b in dst:
        edge_idex.append(int(b.item()))
    for b in src_b:
        src_b_list.append(int(b.item()))
        dst_b_list.append(int(dst_b[idx].item()))
        idx+=1
    
    return  edge_idex,src_b_list,dst_b_list

def dir(fp_sol,i):
        p_x_min=torch.max(torch.tensor(0.0),torch.min(fp_sol[i,:,2]))
        p_x_max=torch.max(fp_sol[i,:,2])
        p_y_min=torch.max(torch.tensor(0.0),torch.min(fp_sol[i,:,3]))
        p_y_max=torch.max(fp_sol[i,:,3])
        coeff_x=(p_x_min+p_x_max)/2
        coeff_y=(p_y_min+p_y_max)/2
        coeff_stack=torch.stack([torch.tensor(0.0),torch.tensor(0.0),coeff_x,coeff_y])
        maxium=torch.max(p_x_max,p_y_max)
        return coeff_stack,maxium

def overlap_rtree(fp_sol, xt, g,size):
    overlap_area = 0
    node_list = g.nodes('block_1')
    
    x_left = xt[:, 0]
    x_right = x_left + fp_sol[:, 0]
    y_bottom = xt[:, 1]
    y_top = y_bottom + fp_sol[:, 1]
    
    # 创建 R 树索引
    p = index.Property()
    rtree_idx = index.Index(properties=p)
    
    # 向 R 树中插入每个节点的最小包围矩形（MBR）
    for i, node in enumerate(node_list):
        rtree_idx.insert(i, (x_left[i].item(), y_bottom[i].item(), x_right[i].item(), y_top[i].item()))
    
    # 遍历每个节点，利用 R 树查找可能重叠的节点
    for i, node_1 in enumerate(node_list):
        rect_1 = (x_left[i].item(), y_bottom[i].item(), x_right[i].item(), y_top[i].item())
        
        # 查询 R 树，获取与当前矩形可能重叠的其他矩形
        potential_overlaps = list(rtree_idx.intersection(rect_1))
        
        for j in potential_overlaps:
            if i >= j:  
                continue
            
            node_2 = node_list[j]
            # 计算真实重叠面积
            if torch.max(x_left[i], x_left[j]) < torch.min(x_right[i], x_right[j]) and \
               torch.max(y_bottom[i], y_bottom[j]) < torch.min(y_top[i], y_top[j]):
                overlap_area += (torch.min(x_right[i], x_right[j]) - torch.max(x_left[i], x_left[j])) * \
                                (torch.min(y_top[i], y_top[j]) - torch.max(y_bottom[i], y_bottom[j]))
    
    return overlap_area

def HPWL(net_info,block_list,pos):
    xt=xt[:,:2]+fea[:,:2]/2.0
    hpwl=0
    for net in net_info:
        x_list=[]
        y_list=[]
        for node in net_info[net]['nodes']:
            if node in block_list:
                # idx = int(node.split('sb')[1])
                idx = int(node.split('_')[1])-1
                x_list.append(xt[idx,0].item())
                y_list.append(xt[idx,1].item())
            else:
                x_list.append(float(pos[node]['x']))
                y_list.append(float(pos[node]['y']))
        x_min, x_max = min(x_list), max(x_list)
        y_min, y_max = min(y_list), max(y_list)
        # 直接将 x 和 y 的差值相加
        hpwl += (x_max - x_min) + (y_max - y_min)
    return hpwl
def idx(net_info,block_list):
    block_idex_list=[]
    pin_idex_list=[]
    for net in net_info:
        for node in net_info[net]['nodes']:
            if node in block_list:
                block_idex_list.append(node)
            else:
                pin_idex_list.append(node)
    return block_idex_list,pin_idex_list

def write_pl(file_name,xt):
    file=os.path.basename(file_name)
    content=""
    file_path=f"{file_name}/{file}.pl"
    file_path_new=f"{file_name}/{file}_new.pl"
    # file_path=f"FloorSetmain/GSRC/{file_name}_soft/{file_name}.pl"
    # file_path_new=f"FloorSetmain/GSRC/{file_name}_soft/{file_name}_new.pl"
    with open(file_path, "r") as f1:
        lines=f1.readlines()
    with open(file_path_new, "w") as f2:
        for line in lines:
            if line.startswith('\t'):
                content=""
                l=line.strip().split()
                idx=int(l[0].split('_')[1])-1
                # idx = int(l[0].split('sb')[1])
                # content+="%s    %d  %d\n"%(l[0],(xt[int(idx),0]+fea[int(idx),0]/2).item(),(xt[int(idx),1]+fea[int(idx),1]/2).item())
                content+="%s    %d  %d DIMS = (%s, %s) N\n"%(l[0],xt[int(idx),0].item(),xt[int(idx),1].item(),fea[int(idx),0].item(),fea[int(idx),0].item())
                f2.write(content)
            else:
                f2.write(line)

def param(file_name):
    file=os.path.basename(file_name)
    json_file=f"./json_file/{file}.json"
    with open(json_file, "r") as f:
        data = json.load(f)
        h_param = data["h"]
        d_param = data["d"]
    return h_param,d_param
def parse_args():
    parser = argparse.ArgumentParser(description="Run the placement optimization script.")
    parser.add_argument('--input_file', type=str, required=True, help='Path to the input file')
    parser.add_argument('--file', type=str, required=True, help='Path to the input file')
    return parser.parse_args()


if __name__=="__main__":
    args = parse_args()
    place_db=placedb(args.file)
    g,size=dgl_graph(place_db.b2b_connect,place_db.fea,place_db.p2b_connect,place_db.pin_pos)
    size=size.to(device)
    fea=g.nodes['block_1'].data['feat'].to(device)
    fea_input=torch.unsqueeze(fea[:,2:],0)
    w_h_size=torch.unsqueeze(fea[:,:2],0)
    fea[:,:2]=w_h_size* size[2:4]
    edge_idex_stack,b2b_src_idex_stack,b2b_dst_idex_stack=pre_hpwl(g)
    h_param,d_param=param(args.input_file)
    xt=predict(fea_input,g.to(device),place_db.Net_info,place_db.block_list,place_db.pos,).squeeze()
    xt=xt* size[2:4]+ size[2:4]
    write_pl(args.input_file,xt)
    print(f"overlap_area :{overlap_rtree(fea, xt, g,size)}")
    wirelength=HPWL(place_db.Net_info,place_db.block_list,place_db.pos)
    print(f"wirelength :{wirelength}")







