import os

# 设置文件夹的父目录
parent_directory = "FloorSetmain/GSRC"

# 设置要创建的文件夹数量
list = [10, 30, 50, 100, 200, 300]  # 文件夹名称中的数字部分


# 循环创建文件夹并生成文件
for i in list:
    # 组合文件夹的完整路径
        folder_path = os.path.join(parent_directory, f"n{i}")
        
        # 创建文件夹
        os.makedirs(folder_path, exist_ok=True)
        

print("Folders and files created successfully.")
