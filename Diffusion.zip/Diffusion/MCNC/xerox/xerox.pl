UCLA pl 1.0
# Created      : Thu Nov 16 15:30:16 PST 2000
# User         : huaizhi@olympus
# Platform     : SunOS 5.6 sparc

BLKB	0	0
BLKD	0	0
BLKLL	0	0
BLKLR	0	0
BLKP	0	0
BLKRC	0	0
BLKRS	0	0
BLKT	0	0
BLKUL	0	0
BLKUR	0	0

VSS	2912	0
VDD	2912	6412
