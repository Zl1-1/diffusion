import torch.nn.functional as F
from typing import Optional
from typing import List
import torch.nn as nn
import numpy as np
import torch
import math
import dgl
import torch.nn.functional as F
from dgl.nn.pytorch import GATv2Conv
import dgl.nn as dglnn
import itertools
from dgl import function as fn

import time



    
class Swish(nn.Module):
    def forward(self, x):
        return x* torch.sigmoid(x)
     
class TimeEmbedding(nn.Module):
    def __init__(self, n_channels:int):
        super().__init__()
        self.n_channels= n_channels  ## 64
        # n_channels// 8 and concate
        self.lin1= nn.Linear(self.n_channels// 4, self.n_channels) # 16->64
        self.act= Swish()   ## 激活函数 x.sigmoid(βx)
        self.lin2= nn.Linear(self.n_channels, self.n_channels)  # 64->64
    def forward(self, t: torch.Tensor):  ## 512
        half_dim= self.n_channels// 8   # 8
        emb= math.log(10000)/ (half_dim- 1)
        emb= torch.exp(torch.arange(half_dim, device= t.device)* -emb)  ## 8
        emb= t[:, None]* emb[None, :]  ## 512 8
        emb= torch.cat((emb.sin(), emb.cos()), dim= 1)  # 512 16
        # transform
        emb= self.act(self.lin1(emb))  ## 512 64
        emb= self.lin2(emb)  ## 512 64
        return emb       

class Res_GNN(nn.Module):
    def __init__(self,in_channels,out_channels,time_channels,head):
         super().__init__()
         self.gatv2_1=GATv2Conv(in_channels,out_channels,head,activation=Swish())
         self.bn1=nn.BatchNorm1d(out_channels)
         self.gatv2_2=GATv2Conv(out_channels*4,out_channels,head,activation=lambda x:x)
        #  self.gatv2=GATv2Conv(in_channels,out_channels,head,activation=Swish())
         self.bn2=nn.BatchNorm1d(out_channels)
         self.time_emb= nn.Linear(time_channels, out_channels)
         self.linear=nn.Linear(out_channels*4,out_channels)
         self.time_act=Swish()
         self.relu=Swish()
         
        #  self.pin_bed=nn.Linear(2,32)
    
    def forward(self,fea,g,t):
        # t=self.time_emb(self.time_act(t))
        assert isinstance(g, dgl.DGLGraph)
        sub_g = g.edge_type_subgraph(['b2b'])
        x=self.gatv2_1(sub_g,fea)
        x = x.permute(0, 2, 1)
        x=self.bn1(x)
        x = x.permute(0, 2, 1)
        x=torch.reshape(x,[fea.shape[0],fea.shape[1],-1])
        x=self.gatv2_2(sub_g,x)
        x = x.permute(0, 2, 1)
        x=self.bn2(x)
        x = x.permute(0, 2, 1)
        x=torch.reshape(x,[fea.shape[0],fea.shape[1],-1])
        x=self.linear(x)
        x=fea+x
        return self.relu(x)


class MLP(nn.Module):
    def __init__(self, in_channel,out_channel):
        super(MLP,self).__init__()
        self.model_1 = nn.Sequential(
            nn.Linear(in_channel,10),
            nn.Sigmoid(),
            nn.Linear(10,10),
            nn.Sigmoid(),
            nn.Linear(10,out_channel),
        )
    def forward(self,x):
        output = self.model_1(x)+x
        return output
class Att_GNN(nn.Module):
    def __init__(self,in_channel,out_channel,head):
        super().__init__()
        self.gatv2_1=GATv2Conv(in_channel,out_channel,head,activation=Swish())
        self.bn1=nn.BatchNorm1d(out_channel)
        # self.att=AttentionBlock(n_channels=out_channel)
        self.att1= nn.MultiheadAttention(embed_dim=out_channel*4, num_heads=head)
        self.gatv2_2=GATv2Conv(out_channel*4,out_channel,head,activation=lambda x:x)
        self.bn2=nn.BatchNorm1d(out_channel)
        # self.att=AttentionBlock(n_channels=out_channel)
        self.att2= nn.MultiheadAttention(embed_dim=out_channel, num_heads=head)
        self.linear=nn.Linear(out_channel*4,out_channel)
        
    def forward(self,fea,g):
        sub_g = g.edge_type_subgraph(['b2b'])
        x=self.gatv2_1(sub_g,fea)
        x = x.permute(0, 2, 1)
        x=self.bn1(x)
        x = x.permute(0, 2, 1)
        x=torch.reshape(x,[fea.shape[0],fea.shape[1],-1])
        x = x.permute(1, 0, 2)
        x,_=self.att1(x,x,x)
        x = x.permute(1, 0, 2)
        x=torch.reshape(x,[fea.shape[0],fea.shape[1],-1])
        x=self.gatv2_2(sub_g,x)
        x = x.permute(0, 2, 1)
        x=self.bn2(x)
        x = x.permute(0, 2, 1)
        x = x.permute(1, 0, 2)
        x,_=self.att2(x,x,x)
        x = x.permute(1, 0, 2)
        x=torch.reshape(x,[fea.shape[0],fea.shape[1],-1])
        x=self.linear(x)
        return x
    
    
    
class Embed(nn.Module):
    def __init__(self,in_channel,out_channel=32):
        super().__init__()
        self.embedding=nn.Linear(in_channel,out_channel)
        self.relu=Swish()
        self.bn=nn.BatchNorm1d(out_channel)
        self.time_embed=TimeEmbedding(out_channel)
        self.linear=nn.Linear(out_channel,out_channel)
        
        

    def forward(self,x,t):
        # x1=x[:,0:2]
        # x2=x[:,2:]
        x=self.embedding(x.float())
        x=self.relu(x)
        x = x.permute(0, 2, 1)
        x=self.bn(x)
        x = x.permute(0, 2, 1)
        x1=sinusoidal_position_embedding(x)
        # x_sin=torch.cat((x1,x2),dim=1)
        t=self.time_embed(t)[:,None]
        x=x+t
        x=self.linear(x.float())
        x=x+x1
        x=self.relu(x)
        return x
    
    
def pos_vecs(pos,output_dim):


    for i in range(pos.shape[2]-1):
        pos[:,:,i] / np.power(10000, 2 * (i // 2) / output_dim)
    return pos
    
 
def sinusoidal_position_embedding(pos):
        pos1 = pos_vecs(pos,pos.shape[2])

        pos_embed = pos.clone()
        pos_embed[:,:,0::2] = torch.sin(pos1[:,:,0::2])  # dim 2t
        pos_embed[:,:,1::2] = torch.cos(pos1[:,:,1::2])  # dim 2t+1
        


        return pos_embed

class Encoder(nn.Module):
    def __init__(self,in_channel,out_channel):
        super().__init__()
        self.embed=Embed(in_channel,out_channel)
        # self.time_enbed=TimeEmbedding(out_channel)
    def forward(self,x,t):
        # t=self.time_enbed(t)
        x=self.embed(x,t)
        return x
class Block(nn.Module):
    def __init__(self,in_channel,out_channel,time_channel,head):
        super().__init__()
        self.res_gnn=Res_GNN(in_channel,out_channel,time_channel,head)
        self.mlp1=MLP(out_channel,out_channel)
        self.att_gnn=Att_GNN(out_channel,out_channel,head)
        self.mlp2=MLP(out_channel,out_channel)
        self.linear=nn.Linear(out_channel,in_channel//16)
        self.sigmod=Swish()
    def forward(self,x,g,t):
        x=x.float()
        x=self.res_gnn(x,g,t)
        x=self.mlp1(x)
        x=self.att_gnn(x,g)
        x=self.mlp2(x)
        x=self.linear(x)
        x=self.sigmod(x)
        return x

class Net(nn.Module):
    def __init__(self,in_channel,out_channel,head,time_channel):
        super().__init__()
        self.encoder= Encoder(in_channel,out_channel)
        self.block=Block(out_channel,out_channel,time_channel,head)
    def forward(self,x,g,t):
        x=self.encoder(x,t)
        x=self.block(x,g,t)
        return x
    
class Tools:
    def gather(self, consts: torch.Tensor, t: torch.Tensor):
        c= consts.gather(-1, t)   
        # return c.reshape(-1, 1, 1, 1)
        return c.reshape(-1, 1,1)
class DenoiseDiffusion(nn.Module):

    def __init__(self, module,n_steps: int, device: torch.device):
        super().__init__()
        self.module=module
        self.beta= torch.linspace(0.0001, 0.02, n_steps).to(device)  ## 生成一维张量
        self.alpha= 1.0- self.beta
        # compute cumulative product
        self.alpha_bar= torch.cumprod(self.alpha, dim= 0) ## 乘积和
        self.n_steps= n_steps
        self.sigma= self.beta
        self.tools= Tools()

    # forward- diffusion
    def q_xt_x0(self, x0: torch.tensor, t:torch.Tensor):
        # compute mean and var of xt according to x0
        # xt= sqrt(at)*x0+ sqrt(1-at)*eps
        mean= self.tools.gather(self.alpha_bar, t)** 0.5* x0  ## 512 1 1 1
        # (batch_size, 1, 1, 1)
        var= 1- self.tools.gather(self.alpha_bar, t)
        return mean, var

    # forward- diffusion
    def q_sample(self, x0: torch.Tensor, t: torch.Tensor, eps: Optional[torch.Tensor]= None):
        # compute xt according mean and var of xt
        if eps is None:
            eps= torch.randn_like(x0)
        mean, var= self.q_xt_x0(x0, t)  ## sqart(at)*x0, 1-(at)
        return mean+ (var** 0.5)* eps   ## xt= sqrt(at)*x0+ sqrt(1-at)*eps  
    
    # DDPM
    def p_sample(self, xt: torch.tensor,g, t: torch.Tensor,edge_idex_stack,b2b_src_idex_stack,b2b_dst_idex_stack,h_param,d_param,net_info,block_list,pos):
        # compute xt-1 according xt
        xt.requires_grad_(True)
        eps_hat_1= self.module(xt, g,t)
        # if eps_hat_1 is None:
        #     raise RuntimeError("eps_hat_1 is None, check the return values of self.module")
        # print(f"self.module(xt, g,t), {eps_hat_1}")
        # gt=self.g_t(xt,g,edge_idex_stack,b2b_src_idex_stack,b2b_dst_idex_stack,h_param,d_param,net_info,block_list,pos)
        # if gt is None:
        #     raise RuntimeError("gt is None, check the return values of self.gt")
        # print(f"gt: {gt}")
    
        # if eps_hat is None:
        #     raise RuntimeError("eps_hat is None, check the return values of self.module or self.gt")
        # print(f"eps_hat, {eps_hat}")
        gt=self.g_t(xt,g,edge_idex_stack,b2b_src_idex_stack,b2b_dst_idex_stack,h_param,d_param,net_info,block_list,pos)
        alpha_bar= self.tools.gather(self.alpha_bar, t)
        alpha= self.tools.gather(self.alpha, t)
        eps_hat=eps_hat_1+gt
        eps_coef= (1- alpha)/ (1- alpha_bar)** 0.5
        mean= 1/ (alpha** 0.5)* (xt- eps_coef* eps_hat)  ## 
        var= self.tools.gather(self.sigma, t)   ##
        eps= torch.randn(xt.shape, device= xt.device)  ## 
        xt_1=mean+ (var** 0.5)* eps
        # x_0=mean
        
        # gt=self.g_t(x_0,g,edge_idex_stack,b2b_src_idex_stack,b2b_dst_idex_stack,h_param,d_param,net_info,block_list,pos)
        # eps_a=eps_hat-torch.sqrt(1-alpha)*gt
        # x1=1/ (alpha** 0.5)* (xt- eps_coef*eps_a)
        # dir_xt=(1-alpha_bar-var**2).sqrt()*eps_a
        # x_pre=alpha_bar.sqrt()*x1+dir_xt+(var** 0.5)* eps
        # xt_1=(alpha_bar/alpha)*x_pre+torch.sqrt(1-alpha_bar/alpha)*(var** 0.5)* eps
        return xt_1



    ### DDIM
    def p_sample1(self, xt: torch.tensor, g, t: torch.Tensor, edge_idex_stack, b2b_src_idex_stack, b2b_dst_idex_stack, h_param, d_param,net_info,block_list,pos, eta: float = 0.0):
    # xt-1
        xt.requires_grad_(True)
        eps_hat_1 = self.module(xt, g, t)
        

        gt=self.g_t(xt,g,edge_idex_stack,b2b_src_idex_stack,b2b_dst_idex_stack,h_param,d_param,net_info,block_list,pos)


        alpha_bar = self.tools.gather(self.alpha_bar, t)
        alpha = self.tools.gather(self.alpha, t)
        

        eps_hat = eps_hat_1 + gt
        

        eps_coef = (1 - alpha) / torch.sqrt(1 - alpha_bar)
        
 
        mean = (1 / torch.sqrt(alpha)) * (xt - eps_coef * eps_hat)
        
  
        var = self.tools.gather(self.sigma, t)
        

        eps = torch.randn_like(xt) * eta
        return mean + torch.sqrt(var) * eps



    def hpwl1(self,xt,g,edge_idex_stack,b2b_src_idex_stack,b2b_dst_idex_stack,fea):
        xt.requires_grad_(True)
        # fea=g.nodes['block_1'].data['feat']
        # fea=torch.reshape(fea,[-1,xt.shape[1],5])
        edge_xt_stack=xt[:,edge_idex_stack,:2]+fea[:,edge_idex_stack,:2]/2.0
        p_fea=g.edges['p2b'].data['weight'][:,:2]
        hpwl=torch.abs(edge_xt_stack-p_fea).sum()
        b2b_src_stack=xt[:,b2b_src_idex_stack,:2]
        b2b_dst_stack=xt[:,b2b_dst_idex_stack,:2]
        hpwl+=torch.abs(b2b_src_stack-b2b_dst_stack).sum()
        # hpwl.backward()
        # g_xt=xt.grad.clone()
        # xt.zero_grad()
        return  hpwl



    def dis(self, xt, g,fea):
        xt.requires_grad_(True)
        dis = torch.tensor(0.0).to(xt.device)

    
        w_h = fea[:, :, :2]  # [batch_size, num_nodes, 2] 
        x_y = xt[:, :, :2]   # [batch_size, num_nodes, 2] 

        diff_x = (x_y[:, :, 0].unsqueeze(1) - x_y[:, :, 0].unsqueeze(2)).abs()  # 
        diff_y = (x_y[:, :, 1].unsqueeze(1) - x_y[:, :, 1].unsqueeze(2)).abs()  #

        # 
        w = w_h[:, :, 0]  # width for all nodes
        h = w_h[:, :, 1]  # height for all nodes

        #
        d_x = torch.where(
            x_y[:, :, 0].unsqueeze(1) >= x_y[:, :, 0].unsqueeze(2),  
            diff_x - w.unsqueeze(2),  
            diff_x - w.unsqueeze(1)  
        )
        d_x = torch.where(d_x < 0, d_x, torch.tensor(0.0,dtype=d_x.dtype).to(xt.device))  


        d_y = torch.where(
            x_y[:, :, 1].unsqueeze(1) >= x_y[:, :, 1].unsqueeze(2),  
            diff_y - h.unsqueeze(2),  
            diff_y - h.unsqueeze(1)  
        )
        d_y = torch.where(d_y < 0, d_y, torch.tensor(0.0,dtype=d_y.dtype).to(xt.device))  

        
        upper_tri_mask = torch.triu(torch.ones_like(d_x), diagonal=1).bool()

        
        d_x = torch.where(upper_tri_mask, d_x, torch.tensor(0.0,dtype=d_x.dtype).to(xt.device))
        d_y = torch.where(upper_tri_mask, d_y, torch.tensor(0.0,dtype=d_y.dtype).to(xt.device))

        
        d = torch.max(d_x, d_y) 


        dis = torch.square(d).sum()

        return dis


    
    def g_t(self,xt,g,edge_idex_stack,b2b_src_idex_stack,b2b_dst_idex_stack,h_param,d_param,net_info,block_list,pos):
        try:
            # print(f"xt: {xt}, g: {g}")
            fea=g.nodes['block_1'].data['feat']
            fea=torch.reshape(fea,[-1,xt.shape[1],4])
            xt.requires_grad_(True)
            xt.retain_grad()
            p_fea=g.edges['p2b'].data['weight'][:,:2]
            # raw_xt = xt.clone()
            # start_time=time.time()
            HPWL=self.hpwl1(xt,g,edge_idex_stack,b2b_src_idex_stack,b2b_dst_idex_stack,fea)

            if HPWL is None:
                raise ValueError("hpwl() returned None")
   
            D=self.dis(xt,g,fea)

            if D is None:
                raise ValueError("dis() returned None")

            Gt=h_param*HPWL+d_param*D 
            g_xt = torch.autograd.grad(
            outputs=Gt,        
            inputs=xt,        
            retain_graph=True, 
            allow_unused=True
        )[0]

            if  g_xt is None:
                print("Warning: grad_xt is None. The input may not be part of the computation graph.")

            return g_xt
        except Exception as e:
            print(f"An  error occurred in g_t :{e}")
            print(f"Current gt value: {Gt}")
            return None

    

        
if __name__=="__main__":
    # node_fea=np.load("npy/mgc_superblue12_fea.npy")
    # X=node_fea[:,2:4]
    # print(node_fea)
    # edge_fea=np.random.rand(3, 4)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # loss_list=[]
    # v=0
    # n=0
    # num_poch=1000
    # best_train_Loss=9999
    #     # X=torch.from_numpy(placedb.fea[:,2:4]).to(device)
    net=Net(2,32,4,32)
    #     # net=DenoiseDiffusion(2,32,4,32,1000)
    dm=DenoiseDiffusion(net,1000)

        
    
    
    
    
    
    
 
