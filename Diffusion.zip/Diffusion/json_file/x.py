import os
import json

# 确保目录存在
os.makedirs('./json_file', exist_ok=True)

# 循环创建文件
for i in range(2, 20):  # 从2到19（包括19）
    file_path = f'./json_file/ibm{i}.json'
    with open(file_path, 'w') as f:
        json.dump({"h": 0.00001, "w": 60}, f)