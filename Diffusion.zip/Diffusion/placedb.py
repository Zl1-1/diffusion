import os 
import numpy as np
import pickle
import dgl
import torch
import re
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Patch, Circle
import matplotlib.patches as patches
from shapely.geometry import Polygon, LineString, Point
import math


    
class placedb():
    def __init__(self,filename):
        self.node_dir, self.block_list=self.ibm_soft_block_size(filename)
        self.pos=self.ibm_read_pl(filename)
        self.Net_info=self.ibm_net_info(filename)
        self.fea=self.fp_sol(self.node_dir,self.pos)
        self.pin_pos=self.pin(self.pos,self.block_list)
        self.b2b_connect,self.p2b_connect=self.ibm_b2b(self.Net_info,self.block_list)

    def ibm_soft_block_size(self,file_name):
        file=os.path.basename(file_name)
        node_dir={}
        block_list=[]
        file_path_nodes=f"{file_name}/{file}.blocks"
        with open(file_path_nodes,"r") as f:
            lines=f.readlines()
            for line in lines:
                if line.startswith("B"):
                    l=line.strip().split()
                    if l[1]=="softrectangular":
                        block_name=l[0]
                        area=float(l[2])
                        min_aspect_ratio=float(l[-2])
                        max_aspect_ratio=float(l[-1])
                        min_width=math.sqrt(area/(1.0+max_aspect_ratio))
                        max_width=math.sqrt(area/(1.0+min_aspect_ratio))
                        w=int(math.sqrt(area))
                        h=int(math.sqrt(area))
                        block_list.append(block_name)
                        node_dir[block_name]={'w':w,'h':h}
                    else:
                        pattern = r"(\w+)\s+(\w+)\s+(\d+)\s+((?:\(\d+,\s*\d+\)\s*)+)"
                        match = re.match(pattern, line)
                        if match:
                            # 提取各个部分
                            block_name = match.group(1)  # sb0
                            shape_type = match.group(2)  # hardrectilinear
                            number = int(match.group(3))  # 4
                            # 提取坐标
                            coordinates_str = match.group(4)
                            coordinates = re.findall(r"\((\d+),\s*(\d+)\)", coordinates_str)
                            coordinates = [(int(x), int(y)) for x, y in coordinates]  # 将坐标转为整数
                            # 输出解析结果
                            w=coordinates[1][1]-coordinates[0][1]
                            h=coordinates[3][0]-coordinates[0][0]
                            node_dir[block_name]={'w':w,'h':h}
                            block_list.append(block_name)
                else:
                    continue
        return node_dir, block_list

    def ibm_read_pl(self,file_name):
        file=os.path.basename(file_name)
        pos={}
        file_path_pl=f"{file_name}/{file}.pl"
        with open(file_path_pl,"r") as f:
            lines=f.readlines()
            for line in lines:
                if line.startswith("\t"):
                    l=line.strip().split()
                    node_name=l[0]
                    pos[node_name]={}
                    pos[node_name]['x']={}
                    pos[node_name]['y']={}
                    pos[node_name]['x']=l[1]
                    pos[node_name]['y']=l[-1]
                else:
                    continue
        return pos
    
    def ibm_net_info(self,file_name):
        file=os.path.basename(file_name)
        net_info={}
        file_path_net=f"{file_name}/{file}.nets"
        count=-1
        with open(file_path_net,"r") as f:
            lines=f.readlines()
            for line in lines:
                if not line.startswith("NetDegree") and not line.startswith(' ') and not line.startswith("\t"):
                    continue
                l=line.strip().split()
                if l[0]=="NetDegree":
                    count+=1
                    net_info[count]={}
                    net_info[count]["nodes"]=[]
                    net_info[count]["NetDegree"]={}
                    net_info[count]["NetDegree"]=l[2]
                else:
                    net_info[count]["nodes"].append(l[0])
        return net_info
    def fp_sol(self,node_dir,pos):
        fea=np.zeros((len(node_dir),4))
        w=[]
        h=[]
        x=[]
        y=[]
        ratio=[]
        for block in node_dir:
            w.append(node_dir[block]['w'])
            h.append(node_dir[block]['h'])
            x.append(pos[block]['x'])
            y.append(pos[block]['y'])
            ratio.append(1)
        fea[:,0]=w
        fea[:,1]=h
        fea[:,2]=x
        fea[:,3]=y
        # fea[:,4]=ratio
        return fea
    def pin(self,pos,block_list):
        pin_pos_x=[]
        pin_pos_y=[]
        for node in pos:
            if node in block_list:
                continue
            pin_pos_x.append(pos[node]['x'])
            pin_pos_y.append(pos[node]['y'])
        pin_pos=np.zeros((len(pin_pos_x),2))
        pin_pos[:,0]=pin_pos_x
        pin_pos[:,1]=pin_pos_y
        return pin_pos
    def b2b(self,net_info,block_list,):
        b2b_list_src=[]
        b2b_list_dst=[]
        p2b_list_src=[]
        p2b_list_dst=[]
        edge_index=[]
        net_id=[]
        for net in net_info:
            if int(net_info[net]['NetDegree'])>2:
                b_list=[]
                p_list=[]
                for node in net_info[net]['nodes']:
                    if node in block_list:
                        b_list.append(node.split('sb')[1])
                    else:
                        p_list.append(int(node.split('p')[1])-1)
                if len(p_list) !=0:
                    edge_index.append(p_list[0])
                    net_id.append(net)
                    for b in b_list:
                        edge_index.append(b)
                        net_id.append(net)
                        p2b_list_src.append(p_list[0]+10)
                        p2b_list_dst.append(b)
                        # i=1
                        # for idex in range(i,len(b_list)):
                        #     b2b_list_src.append(b)
                        #     b2b_list_dst.append(b_list[idex])
                        # i+=1
                else:
                    for b in b_list:
                        j=1
                        for idex in range(j,len(b_list)):
                            edge_index.append(b)
                            net_id.append(net)
                            b2b_list_src.append(b)
                            b2b_list_dst.append(b_list[idex])
                        j+=1
            else:
                if net_info[net]['nodes'][0] in block_list and net_info[net]['nodes'][1] in block_list:
                    b2b_list_src.append(net_info[net]['nodes'][0].split('sb')[1])
                    b2b_list_dst.append(net_info[net]['nodes'][1].split('sb')[1])
                    edge_index.append(net_info[net]['nodes'][0].split('sb')[1])
                    net_id.append(net)
                    edge_index.append(net_info[net]['nodes'][1].split('sb')[1])
                    net_id.append(net)
                else :
                    if net_info[net]['nodes'][0] in block_list:
                        # p2b_list_src.append(int(net_info[net]['nodes'][1].split('p')[1])-1)
                        p2b_list_src.append(int(net_info[net]['nodes'][1].split('p')[1])+9)
                        p2b_list_dst.append(net_info[net]['nodes'][0].split('sb')[1])
                        edge_index.append(int(net_info[net]['nodes'][1].split('p')[1])-1)
                        net_id.append(net)
                        edge_index.append(net_info[net]['nodes'][0].split('sb')[1])
                        net_id.append(net)
                    else:
                        # p2b_list_src.append(int(net_info[net]['nodes'][0].split('p')[1])-1)
                        p2b_list_src.append(int(net_info[net]['nodes'][0].split('p')[1])+9)
                        p2b_list_dst.append(net_info[net]['nodes'][1].split('sb')[1])
                        edge_index.append(int(net_info[net]['nodes'][0].split('p')[1])-1)
                        net_id.append(net)
                        edge_index.append(net_info[net]['nodes'][1].split('sb')[1])
                        net_id.append(net)

        p2b=np.zeros((len(p2b_list_src),2))  
        b2b=np.zeros((len(b2b_list_src),2))
    
        b2b[:,0]=b2b_list_src
        b2b[:,1]=b2b_list_dst
        p2b[:,0]=p2b_list_src
        p2b[:,1]=p2b_list_dst
        return b2b,p2b
    
    def ibm_b2b(self,net_info,block_list,):
        b2b_list_src=[]
        b2b_list_dst=[]
        p2b_list_src=[]
        p2b_list_dst=[]
        edge_index=[]
        net_id=[]
        for net in net_info:
            if int(net_info[net]['NetDegree'])>2:
                b_list=[]
                p_list=[]
                for node in net_info[net]['nodes']:
                    if node in block_list:
                        b_list.append(int(node.split('_')[-1])-1)
                    else:
                        p_list.append(int(node.split('_')[1])-0)
                if len(p_list) !=0:
                    edge_index.append(p_list[0])
                    net_id.append(net)
                    for b in b_list:
                        edge_index.append(b)
                        net_id.append(net)
                        p2b_list_src.append(p_list[0])
                        p2b_list_dst.append(b)
                        # i=1
                        # for idex in range(i,len(b_list)):
                        #     b2b_list_src.append(b)
                        #     b2b_list_dst.append(b_list[idex])
                        # i+=1
                else:
                    for b in b_list:
                        j=1
                        for idex in range(j,len(b_list)):
                            edge_index.append(b)
                            net_id.append(net)
                            b2b_list_src.append(b)
                            b2b_list_dst.append(b_list[idex])
                        j+=1
            else:
                if net_info[net]['nodes'][0] in block_list and net_info[net]['nodes'][1] in block_list:
                    b2b_list_src.append(int(net_info[net]['nodes'][0].split('_')[-1])-1)
                    b2b_list_dst.append(int(net_info[net]['nodes'][1].split('_')[-1])-1)
                    edge_index.append(int(net_info[net]['nodes'][0].split('_')[-1])-1)
                    net_id.append(net)
                    edge_index.append(int(net_info[net]['nodes'][1].split('_')[-1])-1)
                    net_id.append(net)
                else :
                    if net_info[net]['nodes'][0] in block_list:
                        p2b_list_src.append(int(net_info[net]['nodes'][1].split('_')[-1])-0)
                        # p2b_list_src.append(int(net_info[net]['nodes'][1].split('_')[-1])+10)
                        p2b_list_dst.append(net_info[net]['nodes'][0].split('_')[-1]-1)
                        edge_index.append(int(net_info[net]['nodes'][1].split('_')[-1])-0)
                        net_id.append(net)
                        edge_index.append(int(net_info[net]['nodes'][0].split('_')[-1])-1)
                        net_id.append(net)
                    else:
                        p2b_list_src.append(int(net_info[net]['nodes'][0].split('_')[-1])-0)
                        # p2b_list_src.append(int(net_info[net]['nodes'][0].split('_')[-1])+10)
                        p2b_list_dst.append(int(net_info[net]['nodes'][1].split('_')[1])-1)
                        edge_index.append(int(net_info[net]['nodes'][0].split('_')[-1])-0)
                        net_id.append(net)
                        edge_index.append(int(net_info[net]['nodes'][1].split('_')[-1])-1)
                        net_id.append(net)

        p2b=np.zeros((len(p2b_list_src),2))  
        b2b=np.zeros((len(b2b_list_src),2))
    
        b2b[:,0]=b2b_list_src
        b2b[:,1]=b2b_list_dst
        p2b[:,0]=p2b_list_src
        p2b[:,1]=p2b_list_dst
        return b2b,p2b
        
def dgl_graph(b2b, fp_sol,p2b,pins_pos):
        b2b=torch.from_numpy(b2b)
        p2b=torch.from_numpy(p2b)
        fp_sol=torch.from_numpy(fp_sol)
        pins_pos=torch.from_numpy(pins_pos)
        b_pos_src=[]
        b_pos_dst=[]
        p_pos_src=[]
        p_pos_dst=[]
        p_x_min=torch.min(pins_pos[:,0])
        p_x_max=torch.max(pins_pos[:,0])-torch.max(fp_sol[:,0])
        p_y_min=torch.min(pins_pos[:,1])
        p_y_max=torch.max(pins_pos[:,1])-torch.max(fp_sol[:,1])
        coeff_x=(p_x_min+p_x_max)/2
        coeff_y=(p_y_min+p_y_max)/2
        # coeff_stack=torch.stack([torch.tensor(0.0),torch.tensor(0.0),coeff_x,coeff_y])
        # coeff_stack_1=torch.stack([coeff_x,coeff_y,coeff_x,coeff_y])
        area_sum=torch.sum(fp_sol[:,0]*fp_sol[:,1])
        print(f"block_area_sum :{area_sum}")
        norm=torch.sqrt(area_sum*1.0)
        coeff_stack=torch.tensor([0.0, 0.0, norm/2,norm/2])
        coeff_stack_1=torch.tensor([norm/2,norm/2, norm/2,norm/2])
        count=0
        for block in b2b:
            b_pos_src.append((fp_sol[int(block[0].item()),:4]-coeff_stack)/coeff_stack_1)
            b_pos_dst.append((fp_sol[int(block[1].item()),:4]-coeff_stack)/coeff_stack_1)
        for block in p2b:
            if int(block[0].item())>=pins_pos.shape[0]:
                count+=1
                continue
            p_pos_src.append((pins_pos[int(block[0].item()),:]-coeff_stack[2:4])/coeff_stack_1[2:4])
            p_pos_dst.append((fp_sol[int(block[1].item()),2:4]-coeff_stack[2:4])/coeff_stack_1[2:4])
        b2b_src_stack=torch.stack(b_pos_src)
        b2b_dst_stack=torch.stack(b_pos_dst)
        p2b_src_stack=torch.stack(p_pos_src)
        p2b_dst_stack=torch.stack(p_pos_dst)
        b2b_edge_fea=torch.zeros(b2b.shape[0], 4)
        p2b_edge_fea=torch.zeros((p2b.shape[0]-count), 4)
        # p2b_edge_fea=torch.zeros((p2b.shape[0]), 4)
        b2b_edge_fea[:,0]=b2b_src_stack[:,0]
        b2b_edge_fea[:,1]=b2b_src_stack[:,1]
        b2b_edge_fea[:,2]=b2b_dst_stack[:,0]
        b2b_edge_fea[:,3]=b2b_dst_stack[:,1]
        
        p2b_edge_fea[:,0]=p2b_src_stack[:,0]
        p2b_edge_fea[:,1]=p2b_src_stack[:,1]
        p2b_edge_fea[:,2]=p2b_dst_stack[:,0]
        p2b_edge_fea[:,3]=p2b_dst_stack[:,1]
        
        
        # p2b_edge_fea=torch.cat((p2b_edge_fea,b2b_edge_fea[:11,:]),dim=0)
        data_dict = {
            ('block_1', 'b2b', 'block_1'): (b2b[:,0].long(), b2b[:,1].long()),
            ('pin', 'p2b', 'block_2'): (p2b[:,0].long(), p2b[:,1].long())
        }
        
        g = dgl.heterograph(data_dict)
        # 添加节点特征
        fp_sol[:,:4] = (fp_sol[:,:4] - coeff_stack) / coeff_stack_1
        pins=(pins_pos-coeff_stack[2:4])/(coeff_stack[2:4])
        # p2b_fea = torch.cat((fp_sol[:,:2], pins),dim=0)

        # g.nodes['block_1'].data['feat'] = (fp_sol-coeff_stack)/(coeff_stack_1)# 块节点特征
        g.nodes['block_1'].data['feat'] = fp_sol# 块节点特征
        g.nodes['pin'].data['feat'] =(pins_pos-coeff_stack[2:4])/(coeff_stack[2:4])   # 引脚节点特征

        g.edges['b2b'].data['weight'] = b2b_edge_fea  # 块间边的权重
        g.edges['p2b'].data['weight'] = p2b_edge_fea  # 引脚与块间边的权重
        g = dgl.add_self_loop(g, etype='b2b')
        # g = dgl.add_self_loop(g, etype='p2b')
        return g,coeff_stack
        
def visualize_lite(fp_sol, pins_pos,t,h_param,d_param):
    fig, ax = plt.subplots()
    default_color = '#87CEEB'  # 浅蓝色 (类似天空蓝)
    edge_color = 'black'       # 黑色边框
    face_color = '#87CEEB'     # 设置为浅蓝色
    
    # Initialize dimensions
    W, H = 0, 0
    
    # Plot floorplan solution polygons
    all_poly_dict = {}
    for ind, elem in enumerate(fp_sol):
        x = elem[2]
        y = elem[3]
        w = elem[0]
        h = elem[1]
        polygon_list = [(x, y), (x+w, y), (x+w, y+h), (x, y+h), (x, y)]
        unpadded_polygon_list = [point for point in polygon_list if point != [-1.0, -1.0]]
        if len(unpadded_polygon_list) < 4:#ignore padded polygons that are dummy
            continue
        ##poly_elem = Polygon(elem.tolist())
        poly_elem = Polygon(unpadded_polygon_list)
        all_poly_dict[ind] = poly_elem
        # hard_const = placement_constraints[ind]
        
        # face_color, label_text = get_hard_color(hard_const)
        patch = patches.Polygon(
            list(poly_elem.exterior.coords),
            closed=True,
            fill=True,
            edgecolor=edge_color,
            facecolor=face_color,
            # label=label_text,
            alpha=0.5
        )
        ax.add_patch(patch)
        
        llx, lly = poly_elem.bounds[0], poly_elem.bounds[1]
        urx, ury = poly_elem.bounds[2], poly_elem.bounds[3]
        W = max(W, urx)
        H = max(H, ury)
        
        ax.annotate('', (llx, lly), fontsize=6)
    
    # Plot pin positions
    for pname in range(pins_pos.shape[0]):
        x, y = pins_pos[pname]
        circ = Circle((x, y), radius=1, color='g')
        ax.add_patch(circ)

    plt.xlim(0, W )
    plt.ylim(0, H )
    print(f"canvas_area :{W*H}")
    ax.set_aspect('equal', adjustable='box')
    plt.title('Baseline Layout ')
    # print(f"width : {W}\n height: {H}")
    

    path="FloorSetmain/gsrc_image_soft_param"
    if not os.path.exists(path):
        os.system("mkdir -p %s"%(path))
    # out_file=os.path.join(path,"%s_net_info.npy"%(filename))
    plt.savefig(f'{path}/n100_norm_{h_param}_{d_param}_area*1.1_1500'+'.png')
    # plt.savefig(f'{path}/raw'+'.png')
    plt.close()
    return W,H


def plot(coordinates,h_param,d_param):
    # 创建一个新的图像并设置大小
    fig, ax = plt.subplots(figsize=(30, 30))

    # 设置背景为白色
    ax.set_facecolor('white')

    max_x = 0
    max_y = 0
    i=0
    # 绘制每个矩形
    for ind, elem in enumerate(coordinates):
        x = elem[2].item()
        y = elem[3].item()
        w = elem[0].item()
        h = elem[1].item()
    # for x1, y1, w, h,r in coordinates:
        max_x = max(x+w, max_x)
        max_y = max(y+h, max_y)

        ax.add_patch(plt.Rectangle((x, y), w, h, 
                                   facecolor='#87CEEB',   # 矩形填充颜色
                                   edgecolor='black',     # 边框颜色
                                   linewidth=2.5,        # 边框线宽
                                   alpha=0.7))           # 透明度

    # 设置坐标轴范围
    ax.set_xlim(0, max_x)
    ax.set_ylim(0, max_y)    
    ax.set_xticks([])
    ax.set_yticks([])

    # 设置标题和坐标轴标签
    ax.spines['top'].set_linewidth(5)
    ax.spines['bottom'].set_linewidth(5)
    ax.spines['left'].set_linewidth(5)
    ax.spines['right'].set_linewidth(5)
    
    path="result"
    if not os.path.exists(path):
        os.system("mkdir -p %s"%(path))
    # 保存图形
    plt.savefig(f'{path}/{h_param}_{d_param}'+'.png')
    #plt.savefig(f"FloorSetmain/gsrc_image_soft_param/ibm01.svg", dpi=600,pad_inches=0.01)
    print(f"canvas area:{max_x*max_y}")

if __name__=="__main__":

    place_db=placedb('n100')
    # visualize_lite(place_db.fea, place_db.pin_pos,t=00)
    plot(place_db.fea,0,0)


